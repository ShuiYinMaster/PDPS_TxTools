// TxTools.Agent / Tools / PptxExportTool.cs
//
// PPT 生成方案对比:
//   A) 从零建:必须建 Presentation + SlideMaster + SlideLayout + Theme + N 个 Slide,
//      任一环节漏了 PowerPoint 打不开,代码量 400+ 行,细节多。
//   B) 模板法(本文件采用):项目里放一个空白 blank.pptx 作为嵌入资源,工具运行时:
//      1. 从嵌入资源拷贝到目标路径
//      2. 打开 pptx,删除模板里的示例 slide
//      3. 复用模板里现成的 SlideMaster + SlideLayout,追加新 slide(仅含 title + bullets)
//      4. 保存
//      代码量 ~200 行,更稳,视觉靠模板决定用户可定制。
//
// 部署时你需要做:
//   1. 用 PowerPoint 新建一个空白演示文稿 → 另存为 blank.pptx
//      (随便放什么内容都行,推荐留 1 张空白 slide + Office 主题)
//   2. 项目里放到 Resources/blank.pptx
//   3. 项目属性: blank.pptx 的"生成操作(Build Action)"= "嵌入的资源(EmbeddedResource)"
//   4. Rebuild
//   本代码用 EndsWith("blank.pptx") 模糊匹配资源名,不管命名空间是什么都能找到。
//
// 已知限制(为控制代码量):
//   - Slide 只支持 title + bullet points 两个占位符,不支持图片/图表/嵌入表格
//   - 不改 SlideLayout,所有 slide 用模板里的默认布局
//   - bullets 是简单单层列表,不支持缩进/多级
// 需要更花哨的样式,请在模板 pptx 里预设好 layout,或者告诉我加图片/表格支持。

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using Newtonsoft.Json.Linq;
using D = DocumentFormat.OpenXml.Drawing;
using P = DocumentFormat.OpenXml.Presentation;

namespace TxTools.Agent.Core
{
    public sealed class SlideContent
    {
        public string Title { get; set; }
        public List<string> Bullets { get; set; } = new List<string>();
    }

    public sealed class PptxExportTool : ITxAgentTool
    {
        public string Name { get { return "export_pptx"; } }
        public string Description
        {
            get
            {
                return "\u751f\u6210 PowerPoint (.pptx) \u6587\u4ef6\u5230\u684c\u9762 TxTools_Exports \u76ee\u5f55\u3002" +
                       "\u8f93\u5165 file_name + slides([{title,bullets}])\u3002" +
                       "\u4f9d\u8d56\u5185\u5d4c\u7684 blank.pptx \u6a21\u677f\u3002";
            }
        }
        public bool IsReadOnly { get { return false; } }

        public JObject InputSchema
        {
            get
            {
                return JObject.Parse(@"{
                    'type': 'object',
                    'required': ['slides'],
                    'properties': {
                        'file_name': { 'type': 'string', 'description': '文件名,不含扩展名' },
                        'slides': {
                            'type': 'array',
                            'items': {
                                'type': 'object',
                                'properties': {
                                    'title':   { 'type': 'string' },
                                    'bullets': { 'type': 'array', 'items': { 'type': 'string' } }
                                }
                            }
                        }
                    }
                }");
            }
        }

        public string Execute(JObject input)
        {
            var fileName = ToolInputHelpers.String(input["file_name"]);
            var slides = new List<SlideContent>();
            var sTok = input["slides"] as JArray;
            if (sTok != null)
            {
                foreach (var s in sTok)
                {
                    if (!(s is JObject so)) continue;
                    slides.Add(new SlideContent
                    {
                        Title = ToolInputHelpers.String(so["title"]) ?? "",
                        Bullets = ToolInputHelpers.StringList(so["bullets"])
                    });
                }
            }
            if (slides.Count == 0)
                return "Error: slides \u4e3a\u7a7a,\u65e0\u5185\u5bb9\u53ef\u5199\u3002";

            if (string.IsNullOrWhiteSpace(fileName))
                fileName = "presentation_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
            if (!fileName.EndsWith(".pptx", StringComparison.OrdinalIgnoreCase))
                fileName += ".pptx";
            fileName = DocxExportTool.SafeFileName(fileName);

            var outDir = DocxExportTool.GetExportDir();
            var fullPath = Path.Combine(outDir, fileName);

            // 1) 从嵌入资源读 blank.pptx bytes → 拷到目标
            var templateBytes = LoadBlankPptxTemplate();
            if (templateBytes == null)
                return "Error: \u672a\u627e\u5230\u5d4c\u5165\u8d44\u6e90 blank.pptx\u3002" +
                       "\u8bf7\u5c06\u4e00\u4e2a\u7a7a\u767d PowerPoint \u6587\u4ef6\u547d\u540d\u4e3a blank.pptx \u653e\u5165\u9879\u76ee,\u5e76\u8bbe Build Action = EmbeddedResource\u3002";

            File.WriteAllBytes(fullPath, templateBytes);

            // 2) 打开,删掉模板示例 slide,追加新 slide
            using (var pres = PresentationDocument.Open(fullPath, true))
            {
                var presPart = pres.PresentationPart;
                if (presPart == null || presPart.Presentation == null)
                    return "Error: \u6a21\u677f pptx \u65e0 PresentationPart\u3002";

                RemoveAllSlides(presPart);

                // 复用模板第一个 layout
                var layoutPart = presPart.SlideMasterParts.FirstOrDefault()?.SlideLayoutParts.FirstOrDefault();
                if (layoutPart == null)
                    return "Error: \u6a21\u677f\u91cc\u627e\u4e0d\u5230 SlideLayout,\u8bf7\u786e\u8ba4 blank.pptx \u81f3\u5c11\u542b\u4e00\u4e2a slide\u3002";

                var idList = presPart.Presentation.SlideIdList;
                if (idList == null)
                {
                    idList = new SlideIdList();
                    presPart.Presentation.Append(idList);
                }

                uint slideIdSeed = 256U;
                int i = 0;
                foreach (var content in slides)
                {
                    i++;
                    var slidePart = presPart.AddNewPart<SlidePart>();
                    slidePart.Slide = BuildSlide(content.Title, content.Bullets);
                    slidePart.AddPart(layoutPart);

                    idList.Append(new SlideId
                    {
                        Id = (UInt32Value)(slideIdSeed + (uint)i - 1),
                        RelationshipId = presPart.GetIdOfPart(slidePart)
                    });
                }

                presPart.Presentation.Save();
            }

            var size = new FileInfo(fullPath).Length;
            return "\u5df2\u751f\u6210 PowerPoint: " + fullPath +
                   "  (" + FileParserService.FormatBytes(size) + ", " + slides.Count + " \u5f20 slide)";
        }

        // ── 辅助 ──

        private static byte[] LoadBlankPptxTemplate()
        {
            var asm = typeof(PptxExportTool).Assembly;
            var resName = asm.GetManifestResourceNames()
                .FirstOrDefault(n => n.EndsWith("blank.pptx", StringComparison.OrdinalIgnoreCase));
            if (string.IsNullOrEmpty(resName)) return null;

            using (var s = asm.GetManifestResourceStream(resName))
            {
                if (s == null) return null;
                using (var ms = new MemoryStream())
                {
                    s.CopyTo(ms);
                    return ms.ToArray();
                }
            }
        }

        /// <summary>清除 presentation 里所有 slide part 及其在 SlideIdList 的引用。</summary>
        private static void RemoveAllSlides(PresentationPart presPart)
        {
            var idList = presPart.Presentation.SlideIdList;
            var oldSlides = presPart.SlideParts.ToList();
            foreach (var sp in oldSlides)
            {
                var relId = presPart.GetIdOfPart(sp);
                if (idList != null)
                {
                    var sid = idList.Elements<SlideId>().FirstOrDefault(x => x.RelationshipId == relId);
                    if (sid != null) sid.Remove();
                }
                presPart.DeletePart(sp);
            }
        }

        /// <summary>建一个含 title + bullet points 的 slide 结构。</summary>
        private static Slide BuildSlide(string title, IList<string> bullets)
        {
            var slide = new Slide();
            var csd = new CommonSlideData();
            var tree = new ShapeTree();

            // 根 group shape (必需)
            tree.Append(new NonVisualGroupShapeProperties(
                new NonVisualDrawingProperties { Id = 1U, Name = "" },
                new NonVisualGroupShapeDrawingProperties(),
                new ApplicationNonVisualDrawingProperties()));
            tree.Append(new GroupShapeProperties(new D.TransformGroup()));

            // 标题占位符 (顶部)
            if (!string.IsNullOrEmpty(title))
                tree.Append(BuildTextShape(2U, "Title", title,
                    xEmu: 457200L, yEmu: 274638L, cxEmu: 8229600L, cyEmu: 1143000L,
                    fontSizeHalfPt: 32, bold: true));

            // 内容占位符 (标题下方,多行 bullets)
            if (bullets != null && bullets.Count > 0)
                tree.Append(BuildBulletsShape(3U, "Content", bullets,
                    xEmu: 457200L, yEmu: 1600200L, cxEmu: 8229600L, cyEmu: 4525963L));

            csd.ShapeTree = tree;
            slide.CommonSlideData = csd;
            slide.ColorMapOverride = new ColorMapOverride(new D.MasterColorMapping());
            return slide;
        }

        private static Shape BuildTextShape(uint id, string name, string text,
            long xEmu, long yEmu, long cxEmu, long cyEmu, int fontSizeHalfPt, bool bold)
        {
            return new Shape(
                new NonVisualShapeProperties(
                    new NonVisualDrawingProperties { Id = id, Name = name },
                    new NonVisualShapeDrawingProperties(new D.ShapeLocks { NoGrouping = true }),
                    new ApplicationNonVisualDrawingProperties()),
                new ShapeProperties(
                    new D.Transform2D(
                        new D.Offset { X = xEmu, Y = yEmu },
                        new D.Extents { Cx = cxEmu, Cy = cyEmu }
                    ),
                    new D.PresetGeometry(new D.AdjustValueList()) { Preset = D.ShapeTypeValues.Rectangle }
                ),
                new TextBody(
                    new D.BodyProperties { Anchor = D.TextAnchoringTypeValues.Top, Wrap = D.TextWrappingValues.Square },
                    new D.ListStyle(),
                    new D.Paragraph(
                        new D.Run(
                            new D.RunProperties { FontSize = fontSizeHalfPt * 100, Bold = bold, Language = "zh-CN" },
                            new D.Text(text ?? "")
                        )
                    )
                )
            );
        }

        private static Shape BuildBulletsShape(uint id, string name, IList<string> bullets,
            long xEmu, long yEmu, long cxEmu, long cyEmu)
        {
            var body = new TextBody(
                new D.BodyProperties { Anchor = D.TextAnchoringTypeValues.Top, Wrap = D.TextWrappingValues.Square },
                new D.ListStyle()
            );
            foreach (var b in bullets)
            {
                body.Append(new D.Paragraph(
                    new D.ParagraphProperties(new D.CharacterBullet { Char = "\u2022" })
                    { Level = 0, Indent = -228600, LeftMargin = 342900 },
                    new D.Run(
                        new D.RunProperties { FontSize = 2000, Language = "zh-CN" },   // 20 half-pt = 10pt
                        new D.Text(b ?? "")
                    )
                ));
            }

            return new Shape(
                new NonVisualShapeProperties(
                    new NonVisualDrawingProperties { Id = id, Name = name },
                    new NonVisualShapeDrawingProperties(new D.ShapeLocks { NoGrouping = true }),
                    new ApplicationNonVisualDrawingProperties()),
                new ShapeProperties(
                    new D.Transform2D(
                        new D.Offset { X = xEmu, Y = yEmu },
                        new D.Extents { Cx = cxEmu, Cy = cyEmu }
                    ),
                    new D.PresetGeometry(new D.AdjustValueList()) { Preset = D.ShapeTypeValues.Rectangle }
                ),
                body
            );
        }
    }
}
