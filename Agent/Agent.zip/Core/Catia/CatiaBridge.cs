// TxTools.Agent / Core / Catia / CatiaBridge.cs
// late-bound COM 连接 CATIA V5,不依赖 CATIA CAA SDK,不引 Interop dll。
//
// 使用套路:
//   var app = CatiaBridge.GetOrConnect();   // 拿 dynamic (CATIA.Application)
//   dynamic doc = app.ActiveDocument;
//   dynamic root = doc.Product;             // 只有 ProductDocument 才有 .Product
//   foreach (dynamic sub in root.Products) { ... }
//
// 生命周期:
//   - 默认连"已运行"的 CATIA 实例(Marshal.GetActiveObject),不主动启动
//   - 找不到时再 Activator.CreateInstance(...) 启动,并把 Visible = true
//   - COM 对象不主动释放(CATIA 自己是长驻进程,agent 只是查询)
//
// 已知坑:
//   - GetActiveObject 在 .NET 4.8 上标记 Obsolete,但依然可用
//   - CATIA 未响应时调用会挂起 UI 线程 —— 所有 catia_* 工具建议标注"CATIA 若未响应,PS 也会短暂无响应"
//   - Product.Products 是 collection,索引从 1 开始(V5 传统)

using System;
using System.Runtime.InteropServices;

namespace TxTools.Agent.Core.Catia
{
    public static class CatiaBridge
    {
        private const string ProgId = "CATIA.Application";

        // 缓存:同一 form 生命周期内复用
        private static dynamic _app;

        /// <summary>拿到 CATIA.Application(late-bound dynamic)。找不到活跃实例会尝试启动一个新的。</summary>
        public static dynamic GetOrConnect()
        {
            if (_app != null)
            {
                // 简单探活:访问一个便宜属性,失败就重连
                try { var _ = _app.Name; return _app; }
                catch { _app = null; }
            }

            // 1) 尝试连接已运行的
            try { _app = Marshal.GetActiveObject(ProgId); }
            catch (COMException) { _app = null; }

            if (_app != null) return _app;

            // 2) 启动一个新的
            var t = Type.GetTypeFromProgID(ProgId);
            if (t == null)
                throw new InvalidOperationException(
                    "\u672a\u627e\u5230 CATIA V5 (ProgID=" + ProgId + ")\u3002\u786e\u8ba4 CATIA V5 \u5df2\u5b89\u88c5\u5e76\u80fd\u542f\u52a8\u3002");
            _app = Activator.CreateInstance(t);
            try { _app.Visible = true; } catch { }
            return _app;
        }

        /// <summary>连接状态摘要 (供 catia_connect 工具返回)。</summary>
        public static string GetStatusText()
        {
            try
            {
                var app = GetOrConnect();
                string version = "?", activeDoc = "-";
                try { version = (string)app.SystemService.Version; } catch { }
                try { activeDoc = (string)app.ActiveDocument.Name; } catch { activeDoc = "(\u65e0\u6d3b\u52a8\u6587\u6863)"; }
                return "\u5df2\u8fde\u63a5 CATIA V5.\nVersion: " + version + "\nActiveDocument: " + activeDoc;
            }
            catch (Exception ex)
            {
                return "\u8fde\u63a5\u5931\u8d25: " + ex.Message;
            }
        }
    }

    /// <summary>CATIA 树节点的统一数据契约(与 CATIA COM 解耦)。</summary>
    public sealed class CatiaProductNode
    {
        public string Name { get; set; }
        public string PartNumber { get; set; }
        public string Revision { get; set; }
        public string Definition { get; set; }
        public bool IsAssembly { get; set; }
        public System.Collections.Generic.List<CatiaProductNode> Children { get; set; }
            = new System.Collections.Generic.List<CatiaProductNode>();

        public int TotalDescendantCount()
        {
            int n = Children.Count;
            foreach (var c in Children) n += c.TotalDescendantCount();
            return n;
        }
    }

    public static class CatiaTreeReader
    {
        /// <summary>递归读当前 CATIA 活动 Product 文档的整个树。maxDepth 防死递归(有些 CATIA 装配含循环引用)。</summary>
        public static CatiaProductNode ReadActiveTree(int maxDepth = 20)
        {
            var app = CatiaBridge.GetOrConnect();
            dynamic doc = app.ActiveDocument;
            if (doc == null) throw new InvalidOperationException("CATIA \u65e0\u6d3b\u52a8\u6587\u6863\u3002");

            dynamic root;
            try { root = doc.Product; }
            catch { throw new InvalidOperationException("\u5f53\u524d\u6587\u6863\u4e0d\u662f Product\u3002"); }

            return ReadRecursive(root, 0, maxDepth);
        }

        private static CatiaProductNode ReadRecursive(dynamic prod, int depth, int maxDepth)
        {
            var node = new CatiaProductNode
            {
                Name = TryGet(() => (string)prod.Name),
                PartNumber = TryGet(() => (string)prod.PartNumber),
                Revision = TryGet(() => (string)prod.Revision),
                Definition = TryGet(() => (string)prod.Definition),
                IsAssembly = false
            };

            if (depth >= maxDepth) return node;

            try
            {
                dynamic subs = prod.Products;
                int count = 0;
                try { count = (int)subs.Count; } catch { }
                node.IsAssembly = (count > 0);
                // CATIA collection 索引 1..Count
                for (int i = 1; i <= count; i++)
                {
                    try
                    {
                        dynamic child = subs.Item(i);
                        node.Children.Add(ReadRecursive(child, depth + 1, maxDepth));
                    }
                    catch { /* 跳过读不了的子项 */ }
                }
            }
            catch { }

            return node;
        }

        private static T TryGet<T>(Func<T> f)
        {
            try { return f(); } catch { return default(T); }
        }
    }
}
